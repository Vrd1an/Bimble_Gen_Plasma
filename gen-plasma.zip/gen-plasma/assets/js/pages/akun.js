/* Gen Plasma — akun */
function renderAccounts(){
  const list=A()?accounts:accounts.filter(a=>a.role==='Siswa');
  const rows=list.map(a=>`<tr data-search="${(a.name+' '+a.role+' '+a.prog).toLowerCase()}"><td><div class="table-person">${avatar(a.name,a.initials,a.color)}<strong>${a.name}</strong></div></td><td>${A()?`<span class="tag">${a.role}</span>`:a.prog}</td><td>${statusPill(a.status)}</td><td><div class="row-actions">${A()?ra('✎','edit','Ubah',a.name)+ra('⏻','toggle','Aktif / nonaktif',a.name):ra('✎','grade','Catatan',a.name)}</div></td></tr>`).join('');
  return tableShell(A()?['Nama','Role','Status','Aksi']:['Nama','Program','Status','Aksi'],rows);
}
const PAGE={render:renderAccounts,after:bindTableSearch};
