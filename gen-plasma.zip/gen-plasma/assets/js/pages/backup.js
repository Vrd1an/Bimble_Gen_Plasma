/* Gen Plasma — backup data & pemulihan.
   Backup manual benar-benar menghasilkan file .json dari data aplikasi; riwayat disimpan di localStorage.
   Pemulihan masih simulasi (data contoh bersifat statis) — ganti dengan endpoint backend nanti. */
const BK_KEY='gp_backups',BK_AUTO='gp_autobackup';
const BK_SEED=[{id:'s1',name:'backup-20261010-0200',date:'10 Okt 2026, 02.00',size:'46 KB',type:'Otomatis'},{id:'s2',name:'backup-20261009-0200',date:'09 Okt 2026, 02.00',size:'46 KB',type:'Otomatis'},{id:'s3',name:'backup-20261008-0200',date:'08 Okt 2026, 02.00',size:'45 KB',type:'Otomatis'}];
let BK=(()=>{try{const v=JSON.parse(localStorage.getItem(BK_KEY));if(Array.isArray(v))return v}catch(e){}return BK_SEED.map(x=>({...x}))})();
let BK_SEL=null;
const bkSave=()=>{try{localStorage.setItem(BK_KEY,JSON.stringify(BK))}catch(e){}};
const BK_OPTIONS=()=>[...BK].sort((a,b)=>(b.id===BK_SEL)-(a.id===BK_SEL)).map(b=>b.name);

function snapshot(scope){
  const all={programs,schedules,accounts,rooms,durations,levels};
  const keys={'Semua data':Object.keys(all),'Jadwal & program':['programs','schedules','rooms','durations','levels'],'Akun':['accounts']}[scope]||Object.keys(all);
  const data={};keys.forEach(k=>data[k]=all[k]);
  return {aplikasi:'Gen Plasma',versi:1,dibuat:new Date().toISOString(),cakupan:scope,data};
}
function downloadJSON(filename,obj){
  try{const url=URL.createObjectURL(new Blob([JSON.stringify(obj,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);return true}
  catch(e){return false}
}
function createBackup(scope){
  const now=new Date(),p=n=>String(n).padStart(2,'0'),payload=snapshot(scope);
  const name='backup-'+now.getFullYear()+p(now.getMonth()+1)+p(now.getDate())+'-'+p(now.getHours())+p(now.getMinutes());
  const size=Math.max(1,Math.round(JSON.stringify(payload).length/1024))+' KB';
  const date=new Intl.DateTimeFormat('id-ID',{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'}).format(now);
  BK=[{id:'b'+now.getTime(),name,date,size,type:'Manual',scope,payload},...BK].slice(0,10);
  bkSave();const ok=downloadJSON(name+'.json',payload);refreshPage();toast(ok?'Backup dibuat.':'Backup dibuat (unduhan gagal).');
}
function renderBackup(){
  const auto=(()=>{try{return localStorage.getItem(BK_AUTO)}catch(e){return null}})()||'Harian';
  const rows=BK.map(b=>`<tr><td><div class="table-person"><div class="stat-icon purple" style="width:38px;height:38px">▨</div><div><strong>${escapeHTML(b.name)}</strong>${b.scope?`<small>${escapeHTML(b.scope)}</small>`:''}</div></div></td><td>${b.date}</td><td>${b.size}</td><td><span class="tag">${b.type}</span></td><td><div class="row-actions"><button class="row-action" data-bk="dl" data-id="${b.id}" title="Unduh">↓</button><button class="row-action" data-bk="restore" data-id="${b.id}" title="Pulihkan">↺</button><button class="row-action" data-bk="del" data-id="${b.id}" title="Hapus">✕</button></div></td></tr>`).join('')||'<tr><td colspan="5">Belum ada backup.</td></tr>';
  return `<div class="panel panel-pad" style="display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;margin-bottom:18px">
    <label style="display:flex;align-items:center;gap:10px;font-weight:700">Backup otomatis <select class="filter-select" id="autoBackup">${['Nonaktif','Harian','Mingguan'].map(v=>`<option${v===auto?' selected':''}>${v}</option>`).join('')}</select></label>
    <button class="button button-outline" id="restoreBtn">↺ Pulihkan dari file</button><input type="file" id="restoreFile" accept=".json,application/json" hidden>
  </div>
  <div class="panel table-panel"><div class="table-wrap"><table><thead><tr><th>File</th><th>Tanggal</th><th>Ukuran</th><th>Jenis</th><th>Aksi</th></tr></thead><tbody>${rows}</tbody></table></div></div>`;
}
function bindBackup(){
  $('#pageContent').onclick=e=>{
    const b=e.target.closest('[data-bk]');if(!b)return;const item=BK.find(x=>x.id===b.dataset.id);if(!item)return;
    if(b.dataset.bk==='dl')item.payload?downloadJSON(item.name+'.json',item.payload):toast('Data contoh: file tidak tersedia.');
    else if(b.dataset.bk==='restore'){BK_SEL=item.id;openModal('pulihkan')}
    else if(b.dataset.bk==='del'){BK=BK.filter(x=>x.id!==item.id);bkSave();refreshPage();toast('Backup dihapus.')}
    else return;
  };
  $('#autoBackup').onchange=e=>{try{localStorage.setItem(BK_AUTO,e.target.value)}catch(err){}toast('Backup otomatis: '+e.target.value)};
  $('#restoreBtn').onclick=()=>$('#restoreFile').click();
  $('#restoreFile').onchange=e=>{
    const f=e.target.files[0];if(!f)return;const r=new FileReader();
    r.onload=()=>{try{const j=JSON.parse(r.result);if(j.aplikasi!=='Gen Plasma'||!j.data)throw 0;toast('File valid ('+Object.keys(j.data).length+' kelompok data). Pemulihan masih simulasi.')}catch(err){toast('File backup tidak valid.')}};
    r.readAsText(f);e.target.value='';
  };
}
const PAGE={render:renderBackup,after:bindBackup,modalKey:()=>'backup',
  onSave(t){
    if(t==='backup'){createBackup(($('#field0')||{}).value||'Semua data');return true}
    if(t==='pulihkan'){toast('Pemulihan disimulasikan. Data belum diganti.');return true}
    return false;
  }};
