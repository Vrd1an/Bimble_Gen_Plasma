/* Gen Plasma — jenjang */
function renderLevels(){
  return `<div class="simple-grid">${levels.map(l=>`<article class="panel simple-card"><div class="stat-icon ${l.tone}">${l.icon}</div><span class="tag">${l.short}</span><h3 style="margin-top:13px">${l.name}</h3><div class="card-bottom"><span>${l.count} program</span><button class="link-button" data-action="edit" data-name="${l.name}">Ubah →</button></div></article>`).join('')}</div>`;
}
const PAGE={render:renderLevels};
