/* Gen Plasma — durasi */
function renderDurations(){
  return `<div class="simple-grid">${durations.map(d=>`<article class="panel simple-card"><div class="stat-icon ${d.tone}">${d.icon}</div>${statusPill(d.status)}<h3 style="margin-top:13px">${d.name}</h3><div class="stat-value" style="font-size:23px;margin:5px 0 8px">${d.time}</div><div class="card-bottom"><span></span><button class="link-button" data-action="edit" data-name="${d.name}">Ubah →</button></div></article>`).join('')}</div>`;
}
const PAGE={render:renderDurations};
