/* Gen Plasma — dashboard */
function renderDashboard(){
  const stats=S()?[['▦','purple','4','Program'],['▥','mint','6','Sesi bulan ini'],['✓','peach','92%','Kehadiran'],['▥','blue','3','Sesi minggu depan']]
    :T()?[['▦','purple','6','Program'],['▥','mint','12','Sesi minggu ini'],['♙','peach','86','Siswa'],['✓','blue','1','Absensi menunggu']]
    :[['♙','purple','1.296','Siswa'],['◎','mint','48','Tutor'],['▦','peach','36','Program'],['▥','blue','124','Sesi bulan ini']];
  const list=(S()?schedules.filter(s=>myProg.includes(s.prog)):T()?schedules.filter(s=>s.person===me().name):schedules).slice(0,4);
  return `<div class="stats-grid">${stats.map(s=>statCard(...s)).join('')}</div>
  <section class="panel panel-pad"><div class="panel-head"><div><h2 class="panel-title">Jadwal terdekat</h2></div><button class="link-button" data-page="jadwal">Semua →</button></div>
  <div class="schedule-list">${list.map(s=>`<div class="schedule-item"><div class="date-chip"><strong>${s.day}</strong><span>${s.month}</span></div><div class="schedule-info"><strong>${s.title}</strong><span>${s.time} · ${s.room}</span></div>${statusPill(s.status)}</div>`).join('')}</div></section>`;
}
const PAGE={render:renderDashboard,modalKey:()=>T()?'jadwalReq':'jadwal'};
