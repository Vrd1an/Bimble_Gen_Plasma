/* Gen Plasma — ruangan */
function renderRooms(){
  return `<div class="simple-grid">${rooms.map(r=>`<article class="panel simple-card"><div class="stat-icon ${r.tone}">${r.icon}</div>${statusPill(r.status)}<h3 style="margin-top:13px">${r.name}</h3><div class="card-bottom"><span>♙ ${r.capacity}</span><button class="link-button" data-action="edit" data-name="${r.name}">Ubah →</button></div></article>`).join('')}</div>`;
}
const PAGE={render:renderRooms};
