/* Gen Plasma — program */
function renderPrograms(){
  const list=A()?programs:T()?programs.filter(p=>p.teacher===me().name):programs.filter(p=>p.status==='Aktif');
  const foot=p=>A()?`<button class="link-button" data-action="viewProgram" data-name="${p.name}">Kelola →</button>`:(T()||myProg.includes(p.name))?`<button class="link-button" data-page="jadwal">Jadwal →</button>`:`<button class="link-button" data-action="enroll" data-name="${p.name}">Daftar →</button>`;
  const pill=p=>S()&&myProg.includes(p.name)?statusPill('Terdaftar'):statusPill(p.status);
  const cards=list.map(p=>`<article class="panel program-card" data-search="${(p.name+' '+p.level+' '+p.teacher).toLowerCase()}"><div class="program-cover ${p.art}"><span class="cover-emoji">${p.emoji}</span></div><div class="program-body">${pill(p)}<h3>${p.name}</h3><div class="program-meta"><span>${p.level}</span><span>♙ ${p.students}</span></div><div class="program-meta"><span>${T()?'':p.teacher}</span>${foot(p)}</div></div></article>`).join('');
  return `<div class="panel table-panel" style="margin-bottom:18px"><div class="table-toolbar"><div class="searchbox"><span>⌕</span><input id="cardSearch" type="search" placeholder="Cari..."></div><select class="filter-select" id="programFilter"><option value="">Semua jenjang</option><option>SD</option><option>SMP</option><option>SMA</option></select></div></div><div class="cards-grid" id="programCards">${cards}</div>`;
}
const PAGE={render:renderPrograms,after:()=>bindCardSearch('programCards','cardSearch','programFilter')};
