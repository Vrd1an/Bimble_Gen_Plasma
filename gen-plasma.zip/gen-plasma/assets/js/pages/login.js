/* Gen Plasma — halaman login (simulasi, tanpa backend). Kredensial hanya contoh. */
const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];
const demo = { admin:['admin@genplasma.id','admin123'], tutor:['nadia@genplasma.id','tutor123'], student:['raka@genplasma.id','siswa123'] };
let loginRole = 'admin';
try { if (roleProfiles[sessionStorage.getItem('gp_role')]) location.replace('dashboard.html'); } catch(e) {}

function fillLogin(){
  $('#loginEmail').value = demo[loginRole][0]; $('#loginPass').value = demo[loginRole][1]; $('#loginError').hidden = true;
  $$('#roleTabs button').forEach(b => b.classList.toggle('on', b.dataset.role === loginRole));
  $('#loginHint').textContent = 'Akun demo terisi otomatis.';
}
function doLogin(){
  const [em, pw] = demo[loginRole];
  if ($('#loginEmail').value.trim().toLowerCase() !== em || $('#loginPass').value !== pw) { $('#loginError').hidden = false; return; }
  try { sessionStorage.setItem('gp_role', loginRole); } catch(e) {}
  location.assign('dashboard.html');
}
$('#roleTabs').addEventListener('click', e => { const b = e.target.closest('button'); if (b) { loginRole = b.dataset.role; fillLogin(); } });
$('#passToggle').addEventListener('click', () => { const p = $('#loginPass'), h = p.type === 'password'; p.type = h ? 'text' : 'password'; $('#passToggle').textContent = h ? 'Sembunyi' : 'Lihat'; });
$('#loginBtn').addEventListener('click', doLogin);
$$('#loginForm input').forEach(i => i.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); doLogin(); } }));
fillLogin();
