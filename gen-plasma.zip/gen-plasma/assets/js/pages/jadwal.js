/* Gen Plasma — jadwal */
function renderSchedule(){
 const list=A()?schedules:T()?schedules.filter(s=>s.person===me().name):schedules.filter(s=>myProg.includes(s.prog));
 const live=s=>s.status==='Berlangsung';
 const acts=s=>A()?ra('✎','edit','Ubah jadwal',s.title)+ra('✕','del','Hapus jadwal',s.title):T()?ra('✓','attend','Isi absensi',s.title)+ra('✎','reqchange','Ajukan perubahan',s.title):ra(live(s)?'▶':'⏰',live(s)?'join':'remind',live(s)?'Gabung kelas':'Ingatkan saya',s.title);
 const rows=list.map(s=>`<tr data-search="${(s.title+' '+s.person+' '+s.room+' '+s.status).toLowerCase()}"><td><div class="table-person"><div class="date-chip"><strong>${s.day}</strong><span>${s.month}</span></div><div><strong>${s.title}</strong><small>${s.room}</small></div></div></td><td>${s.time}</td><td>${T()?s.n+' siswa':s.person}</td><td>${statusPill(s.status)}</td><td><div class="row-actions">${acts(s)}</div></td></tr>`).join('');
 return tableShell(['Sesi','Waktu',T()?'Peserta':'Tutor','Status','Aksi'],rows);
}

const PAGE={render:renderSchedule,after:bindTableSearch,modalKey:()=>T()?'jadwalReq':'jadwal'};
