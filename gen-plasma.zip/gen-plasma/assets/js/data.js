/* Gen Plasma — data contoh, role, menu, dan hak akses (pengganti database sementara) */
const roleNames = {admin:'Administrator', tutor:'Tutor / Pengajar', student:'Siswa'};
const roleProfiles = {
  admin:{name:'Early Akbar', initials:'EA',email:'admin@genplasma.id', greeting:'Dashboard',},
  tutor:{name:'Nadia Putri', initials:'NP', email:'nadia@genplasma.id', greeting:'Halo, Nadia',},
  student:{name:'Raka Pratama', initials:'RP', email:'raka@genplasma.id', greeting:'Halo, Raka',}
};
const programs = [
  {name:'Matematika Ceria',category:'Akademik',level:'SMP',teacher:'Nadia Putri',students:128,progress:78,emoji:'📐',art:'art-lilac',status:'Aktif'},
  {name:'English Adventure',category:'Bahasa',level:'SMA',teacher:'Kevin Wijaya',students:96,progress:64,emoji:'🌎',art:'art-blue',status:'Aktif'},
  {name:'Sains Eksplorasi',category:'Akademik',level:'SD',teacher:'Dina Maharani',students:84,progress:52,emoji:'🧪',art:'art-mint',status:'Aktif'},
  {name:'Persiapan UTBK',category:'Persiapan ujian',level:'SMA',teacher:'Fajar Ramadhan',students:72,progress:45,emoji:'🎯',art:'art-peach',status:'Draft'},
  {name:'Coding Junior',category:'Teknologi',level:'SMP',teacher:'Ardi Saputra',students:55,progress:35,emoji:'💻',art:'art-blue',status:'Aktif'},
  {name:'Kelas Menulis',category:'Bahasa',level:'SD',teacher:'Maya Safitri',students:43,progress:68,emoji:'✍️',art:'art-peach',status:'Aktif'}
];

const schedules = [
  {day:'10',month:'OKT',title:'Matematika — Persamaan Linear',time:'08.00 – 09.00',person:'Nadia Putri',room:'Virtual Room 01',status:'Berlangsung'},
  {day:'10',month:'OKT',title:'English Conversation',time:'10.00 – 11.00',person:'Kevin Wijaya',room:'Ruang Belajar 2',status:'Akan datang'},
  {day:'11',month:'OKT',title:'Sains — Sistem Tata Surya',time:'13.00 – 14.30',person:'Dina Maharani',room:'Virtual Room 03',status:'Akan datang'},
  {day:'12',month:'OKT',title:'Persiapan UTBK',time:'15.30 – 17.00',person:'Fajar Ramadhan',room:'Virtual Room 01',status:'Akan datang'}
];

const accounts = [
  {name:'Nadia Putri',email:'nadia.putri@example.com',role:'Tutor',status:'Aktif',initials:'NP',color:'avatar-green'},
  {name:'Raka Pratama',email:'raka.pratama@example.com',role:'Siswa',status:'Aktif',initials:'RP',color:'avatar-purple'},
  {name:'Kevin Wijaya',email:'kevin.wijaya@example.com',role:'Tutor',status:'Aktif',initials:'KW',color:'avatar-orange'},
  {name:'Dina Maharani',email:'dina.maharani@example.com',role:'Tutor',status:'Menunggu',initials:'DM',color:'avatar-pink'},
  {name:'Alya Permata',email:'alya.permata@example.com',role:'Siswa',status:'Aktif',initials:'AP',color:'avatar-pink'},
  {name:'Fajar Ramadhan',email:'fajar.ramadhan@example.com',role:'Tutor',status:'Aktif',initials:'FR',color:'avatar-blue'}
];

const rooms = [
  {name:'Virtual Room 01',type:'Virtual',capacity:'30 peserta',status:'Aktif',icon:'💻',tone:'purple'},
  {name:'Ruang Belajar 2',type:'Fisik',capacity:'24 peserta',status:'Aktif',icon:'🏫',tone:'blue'},
  {name:'Virtual Room 03',type:'Virtual',capacity:'30 peserta',status:'Aktif',icon:'🌐',tone:'mint'},
  {name:'Ruang Diskusi A',type:'Fisik',capacity:'12 peserta',status:'Perawatan',icon:'🪑',tone:'peach'}
];

const durations = [
  {name:'Sesi Singkat',time:'30 menit',desc:'Untuk konsultasi atau latihan singkat.',status:'Aktif',icon:'⚡',tone:'peach'},
  {name:'Sesi Reguler',time:'45 menit',desc:'Durasi belajar fokus untuk satu topik.',status:'Aktif',icon:'📘',tone:'purple'},
  {name:'Sesi Mendalam',time:'60 menit',desc:'Untuk pembahasan materi lebih menyeluruh.',status:'Aktif',icon:'🎓',tone:'mint'},
  {name:'Sesi Intensif',time:'90 menit',desc:'Sesi khusus latihan dan persiapan ujian.',status:'Draft',icon:'🚀',tone:'blue'}
];

const levels = [
  {name:'Sekolah Dasar',short:'SD',desc:'Fondasi belajar dan eksplorasi dasar.',count:12,icon:'🌱',tone:'mint'},
  {name:'Sekolah Menengah Pertama',short:'SMP',desc:'Penguatan konsep dan kemandirian belajar.',count:18,icon:'📚',tone:'purple'},
  {name:'Sekolah Menengah Atas',short:'SMA',desc:'Pendalaman materi dan persiapan ujian.',count:15,icon:'🎓',tone:'blue'}
];


// Pelengkap data contoh supaya setiap role punya isi
programs.find(p=>p.name==='Kelas Menulis').teacher='Nadia Putri';
schedules.forEach((s,i)=>{s.prog=['Matematika Ceria','English Adventure','Sains Eksplorasi','Persiapan UTBK'][i];s.n=[28,24,22,18][i]});
schedules.push({day:'13',month:'OKT',title:'Kelas Menulis — Menyusun Cerpen',time:'09.00 – 10.00',person:'Nadia Putri',room:'Ruang Belajar 2',status:'Akan datang',prog:'Kelas Menulis',n:20},{day:'14',month:'OKT',title:'Matematika — Pertidaksamaan',time:'08.00 – 09.00',person:'Nadia Putri',room:'Virtual Room 01',status:'Akan datang',prog:'Matematika Ceria',n:28});
accounts.push({name:'Nabila Zahra',email:'nabila.zahra@example.com',role:'Siswa',status:'Aktif',initials:'NZ',color:'avatar-green'});
accounts.forEach(a=>a.prog={'Raka Pratama':'Matematika Ceria','Alya Permata':'Matematika Ceria','Nabila Zahra':'Kelas Menulis'}[a.name]||'—');
const myProg=['Matematika Ceria','English Adventure','Sains Eksplorasi','Coding Junior'];

// Metadata halaman (judul, subjudul, tombol aksi) — default untuk admin
const PAGES={
  dashboard:{title:'Dashboard',action:'＋ Tambah jadwal',crumb:'Dashboard'},
  program:{title:'Program bimbel',action:'＋ Tambah program',crumb:'Program bimbel'},
  jadwal:{title:'Jadwal belajar',action:'＋ Tambah jadwal',crumb:'Jadwal belajar'},
  ruangan:{title:'Kelola ruangan',action:'＋ Tambah ruangan',crumb:'Ruangan'},
  durasi:{title:'Durasi & sesi',action:'＋ Tambah sesi',crumb:'Durasi & sesi'},
  jenjang:{title:'Kelola jenjang',action:'＋ Tambah jenjang',crumb:'Jenjang'},
  akun:{title:'Kelola akun',action:'＋ Tambah akun',crumb:'Kelola akun'},
  backup:{title:'Backup data',action:'＋ Buat backup',crumb:'Backup data'}
};
// Penyesuaian per role
const OV={
  tutor:{dashboard:{action:'＋ Ajukan perubahan'},program:{title:'Program yang saya ampu',action:'',crumb:'Program saya'},jadwal:{title:'Jadwal mengajar',action:'＋ Ajukan perubahan',crumb:'Jadwal mengajar'},akun:{title:'Murid saya',action:'',crumb:'Murid saya'}},
  student:{dashboard:{action:''},program:{title:'Jelajahi program',action:'',crumb:'Program'},jadwal:{title:'Jadwal belajarku',action:'',crumb:'Jadwal saya'}}
};
// Menu & hak akses per role (halaman yang tidak ada di sini tidak bisa dibuka)
const NAVI={dashboard:'⌂',program:'▦',jadwal:'▥',ruangan:'▣',durasi:'◷',jenjang:'⌑',akun:'♙',backup:'▨'};
const MENU={
  admin:[['',['dashboard']],['MANAJEMEN',['program','jadwal','ruangan','durasi','jenjang']],['PENGGUNA',['akun']],['SISTEM',['backup']]],
  tutor:[['',['dashboard']],['MENGAJAR',['program','jadwal','akun']]],
  student:[['',['dashboard']],['BELAJAR',['program','jadwal']]]
};
const A=()=>state.role==='admin',T=()=>state.role==='tutor',S=()=>state.role==='student',me=()=>roleProfiles[state.role];
const pg=(id=state.page)=>({...PAGES[id],...((OV[state.role]||{})[id]||{})});
const allowed=id=>MENU[state.role].some(m=>m[1].includes(id));
