/* Terapkan tema tersimpan sebelum halaman tampil (hindari kedipan) */
try{var t=localStorage.getItem('gp_theme');if(t)document.documentElement.setAttribute('data-theme',t)}catch(e){}
