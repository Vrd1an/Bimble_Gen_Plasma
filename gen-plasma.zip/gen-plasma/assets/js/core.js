/* Gen Plasma — inti aplikasi: sesi login, navbar, modal, toast, helper tampilan */
const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const state = { page: document.body.dataset.slug, role: 'admin', search: '', modalType: '', theme: 'light' };
function go(url){ location.assign(url); }
const ra=(i,a,t,n='')=>`<button class="row-action" data-action="${a}" data-name="${escapeHTML(n)}" title="${t}">${i}</button>`;

/* ---------- ikon, helper tampilan ---------- */
const escapeHTML = value => String(value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const P={db:'<ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v6c0 1.7 3.6 3 8 3s8-1.3 8-3V6M4 12v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6"/>',restore:'<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/>',home:'<path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10v9.5h13V10"/>',book:'<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v16H6.5A2.5 2.5 0 0 0 4 21.5z"/><path d="M4 5.5v16"/>',cal:'<rect x="3.5" y="5" width="17" height="15.5" rx="2"/><path d="M3.5 10h17M8 3v4M16 3v4"/>',room:'<path d="M4 21V5l8-2 8 2v16"/><path d="M9 21v-5h6v5M9 9h.01M15 9h.01M9 12.5h.01M15 12.5h.01"/>',clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',layers:'<path d="m12 3 9 5-9 5-9-5z"/><path d="m3 13 9 5 9-5"/>',user:'<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7"/>',users:'<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.8 2.9-6 6.5-6s6.5 2.2 6.5 6M16 4.7a3.5 3.5 0 0 1 0 6.6M18 14.5c2.2.6 3.5 2.4 3.5 5.5"/>',star:'<path d="m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',image:'<rect x="3.5" y="4" width="17" height="16" rx="2"/><circle cx="9" cy="10" r="1.6"/><path d="m4 18 5-5 4 4 3-3 4 4"/>',bell:'<path d="M6 16v-5a6 6 0 1 1 12 0v5l1.5 2h-15z"/><path d="M10 21h4"/>',plus:'<path d="M12 5v14M5 12h14"/>',search:'<circle cx="11" cy="11" r="6.5"/><path d="m20 20-4.2-4.2"/>',filter:'<path d="M4 6h16M7 12h10M10 18h4"/>',ext:'<path d="M7 17 17 7M8 7h9v9"/>',edit:'<path d="M4 20h4L19 9l-4-4L4 16z"/>',x:'<path d="M6 6l12 12M18 6 6 18"/>',power:'<path d="M12 3v9"/><path d="M6.5 6.5a8 8 0 1 0 11 0"/>',play:'<path d="M8 5v14l11-7z"/>',check:'<path d="m5 12.5 4.5 4.5L19 7.5"/>',moon:'<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>',sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2.5v2M12 19.5v2M2.5 12h2M19.5 12h2M5.3 5.3l1.4 1.4M17.3 17.3l1.4 1.4M5.3 18.7l1.4-1.4M17.3 6.7l1.4-1.4"/>',menu:'<path d="M4 7h16M4 12h16M4 17h16"/>',right:'<path d="M5 12h14M13 6l6 6-6 6"/>',down:'<path d="M12 4v13M6 12l6 6 6-6"/>',pin:'<path d="M12 21s7-6.2 7-11.5A7 7 0 0 0 5 9.5C5 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/>',heart:'<path d="M12 20s-7.5-4.6-7.5-10A4.3 4.3 0 0 1 12 7.2 4.3 4.3 0 0 1 19.5 10c0 5.4-7.5 10-7.5 10z"/>',teach:'<path d="m12 4 10 5-10 5L2 9z"/><path d="M6 11.5V16c3.3 2.6 8.7 2.6 12 0v-4.5"/>',award:'<circle cx="12" cy="9" r="5.5"/><path d="m8.5 14-1.5 7 5-3 5 3-1.5-7"/>',msg:'<path d="M4 5h16v11H9l-5 4z"/>',bulb:'<path d="M9 18h6M10 21h4"/><path d="M12 3a6 6 0 0 0-3.5 10.9c.6.5 1 1.3 1 2.1h5c0-.8.4-1.6 1-2.1A6 6 0 0 0 12 3z"/>',monitor:'<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/>',globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/>',bolt:'<path d="M13 3 5 13.5h6L10 21l8-10.5h-6z"/>',rocket:'<path d="M5 19c0-3 1-5 3-7l5-5c3-3 6-3 6-3s0 3-3 6l-5 5c-2 2-4 3-6 4z"/><circle cx="15" cy="9" r="1.5"/>',sprout:'<path d="M12 21v-9"/><path d="M12 12c0-4 2.5-6 7-6 0 4-2.5 6-7 6zM12 15c0-3-2-5-6-5 0 3 2 5 6 5z"/>',file:'<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4M9 12h6M9 16h6"/>',planet:'<circle cx="12" cy="12" r="5"/><path d="M3 15c3 2 15-3 18-6"/>',ruler:'<path d="M4 4v16h16z"/><path d="M4 12h3M4 8h2M12 20v-3M8 20v-2"/>',abc:'<path d="m4 18 4-12 4 12M5.5 14h5M15 8h5M15 12h5M15 16h5"/>',flask:'<path d="M9 3h6M10 3v6l-5 9a2 2 0 0 0 1.8 3h10.4a2 2 0 0 0 1.8-3l-5-9V3"/>',target:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.2"/>',checkc:'<circle cx="12" cy="12" r="9"/><path d="m8 12.5 3 3 5-6"/>',tool:'<path d="M14 7a4 4 0 0 0 5 5l-8 8a2 2 0 0 1-3-3z"/>',clip:'<path d="m20 11-8.5 8.5a5 5 0 0 1-7-7L13 4a3.5 3.5 0 0 1 5 5l-8.5 8.5a2 2 0 0 1-3-3L14 7"/>'};
const MAP={'▨':'db','↺':'restore','⌂':'home','▦':'book','▥':'cal','▣':'room','◷':'clock','⏰':'clock','⌑':'layers','♙':'user','☆':'star','★':'starf','▧':'image','♧':'bell','＋':'plus','⌕':'search','☷':'filter','↗':'ext','✎':'edit','✕':'x','⏻':'power','▶':'play','✓':'check','☾':'moon','☀':'sun','☰':'menu','→':'right','↓':'down','⌖':'pin','♥':'heart','◎':'teach','◇':'award','▤':'msg','💡':'bulb','💻':'monitor','🌐':'globe','🌎':'globe','🏫':'room','🪑':'users','⚡':'bolt','📘':'book','🎓':'teach','🚀':'rocket','🌱':'sprout','📚':'book','📒':'file','🪐':'planet','📐':'ruler','🔤':'abc','🗓':'cal','📅':'cal','🧪':'flask','🎯':'target','✍':'edit','🎉':'checkc','✅':'checkc','⭐':'starf','👋':'bell','👤':'user','🛠':'tool','📎':'clip','🏅':'award','✦':'','✨':''};
const RXsrc='('+Object.keys(MAP).map(k=>k.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('|')+')\uFE0F?',RXT=new RegExp(RXsrc),RXS=new RegExp(RXsrc,'g');
const svgIcon=n=>n==='starf'?`<svg class="ic fill" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round" aria-hidden="true">${P.star}</svg>`:`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${P[n]}</svg>`;
function iconize(root){const w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,{acceptNode:n=>/^(SCRIPT|STYLE|TEXTAREA|OPTION|TITLE)$/.test(n.parentNode.nodeName)||!RXT.test(n.nodeValue)?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT}),L=[];while(w.nextNode())L.push(w.currentNode);
 L.forEach(n=>{const t=document.createElement('template');t.innerHTML=escapeHTML(n.nodeValue).replace(RXS,(m,c)=>MAP[c]?svgIcon(MAP[c]):'');n.replaceWith(t.content)})}
function labelTables(){$$('table').forEach(t=>{const hd=[...t.querySelectorAll('th')].map(x=>x.textContent.trim());t.querySelectorAll('tbody tr').forEach(r=>[...r.children].forEach((td,i)=>{if(!i)return;if(/^aksi$/i.test(hd[i]||''))td.classList.add('act');else td.dataset.label=hd[i]||''}))})}
function toast(message){const el=$('#toast');el.textContent=message;el.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.classList.remove('show'),2600)}
function statusClass(status){return ['Aktif','Berlangsung','Terdaftar'].includes(status)?'active':(['Draft','Menunggu','Akan datang'].includes(status)?'pending':'inactive')}
function statusPill(status){return `<span class="status ${statusClass(status)}">${escapeHTML(status)}</span>`}
function avatar(name, initials, color='avatar-purple'){return `<div class="avatar ${color}">${escapeHTML(initials||name.split(' ').map(x=>x[0]).slice(0,2).join(''))}</div>`}
function tableShell(headers, rows){
 return `<div class="panel table-panel"><div class="table-toolbar"><div class="searchbox"><span>⌕</span><input id="tableSearch" type="search" placeholder="Cari..." value="${escapeHTML(state.search)}"></div></div><div class="table-wrap"><table><thead><tr>${headers.map(h=>`<th>${h}</th>`).join('')}</tr></thead><tbody id="tableBody">${rows}</tbody></table></div></div>`;
}
function statCard(icon,tone,value,label){return `<article class="stat-card"><div class="stat-top"><div class="stat-icon ${tone}">${icon}</div></div><div class="stat-value">${value}</div><div class="stat-label">${label}</div></article>`}
function bindTableSearch(){const input=$('#tableSearch');if(!input)return;input.addEventListener('input',()=>{state.search=input.value.toLowerCase();$$('#tableBody tr').forEach(r=>{r.hidden=!r.dataset.search.includes(state.search)})})}
function bindCardSearch(containerId,inputId,filterId){
 const input=$('#'+inputId),filter=$('#'+filterId);if(!input)return;
 const run=()=>{let count=0;$$('#'+containerId+' > *').forEach(card=>{const search=(card.dataset.search||card.textContent).toLowerCase();const match=search.includes(input.value.toLowerCase())&&(!filter||!filter.value||search.includes(filter.value.toLowerCase()));card.hidden=!match;if(match)count++})};
 input.addEventListener('input',run);if(filter)filter.addEventListener('change',run);
}

/* ---------- modal & toast (dibuat oleh JS agar tidak diulang di setiap halaman) ---------- */
function ensureOverlay(){
  document.body.insertAdjacentHTML('beforeend',`<div class="toast" id="toast" role="status" aria-live="polite"></div>
  <div class="modal-backdrop" id="modalBackdrop" hidden><section class="modal" role="dialog" aria-modal="true" aria-labelledby="modalTitle">
    <div class="modal-head"><div><h2 id="modalTitle">Tambah data</h2></div><button class="icon-button" id="modalClose" aria-label="Tutup">×</button></div>
    <div id="modalBody"></div>
    <div class="modal-footer"><button class="button button-quiet" id="modalCancel">Batal</button><button class="button button-primary" id="modalSave">Simpan</button></div>
  </section></div>`);
}
function openModal(type='generic',name=''){
 state.modalType=type;
 const tutors=accounts.filter(a=>a.role==='Tutor').map(a=>a.name);
 const configs={
 program:{title:'Tambah program',fields:[['Nama program','text',''],['Jenjang','select',['SD','SMP','SMA']],['Tutor','select',tutors]]},
 jadwal:{title:'Tambah jadwal',fields:[['Nama sesi','text',''],['Tanggal','date',''],['Waktu mulai','time',''],['Durasi','select',durations.map(d=>d.time)],['Tutor','select',tutors],['Ruangan','select',rooms.map(r=>r.name)]]},
 akun:{title:'Tambah akun',fields:[['Nama','text',''],['Email','email',''],['Role','select',['Admin','Tutor','Siswa']]]},
 ruangan:{title:'Tambah ruangan',fields:[['Nama ruangan','text',''],['Jenis','select',['Virtual','Fisik']],['Kapasitas','number','']]},
 durasi:{title:'Tambah durasi',fields:[['Nama sesi','text',''],['Durasi (menit)','number','']]},
 jenjang:{title:'Tambah jenjang',fields:[['Nama jenjang','text','']]},
 jadwalReq:{title:'Ajukan perubahan jadwal',fields:[['Sesi','select',schedules.filter(s=>s.person===me().name).map(s=>s.title)],['Tanggal baru','date',''],['Waktu baru','time','']]},
 absensi:{title:'Absensi',fields:accounts.filter(a=>a.role==='Siswa').map(a=>[a.name,'select',['Hadir','Izin','Sakit','Alpa']])},
 catatan:{title:'Catatan',fields:[['Catatan','text','']]},
 backup:{title:'Buat backup',fields:[['Cakupan','select',['Semua data','Jadwal & program','Akun']]]},
 pulihkan:{title:'Pulihkan data',fields:[['Titik pemulihan','select',(typeof BK_OPTIONS==='function')?BK_OPTIONS():[]]]},
 profile:{title:'Profil',fields:[['Nama','text',roleProfiles[state.role].name],['Email','email',me().email],['Role','text',roleNames[state.role]]]},
 generic:{title:'Ubah data',fields:[['Nama','text','']]}
 };
 const cfg=configs[type]||configs.generic;
 $('#modalTitle').textContent=name||cfg.title;
 $('#modalBody').innerHTML=`<form class="modal-form" id="demoForm">${cfg.fields.map((f,i)=>{const id='field'+i;let control='';if(f[1]==='select'){control=`<select id="${id}" ${i===0?'required':''}>${f[2].map(v=>`<option>${escapeHTML(v)}</option>`).join('')}</select>`}else if(f[1]==='textarea'){control=`<textarea id="${id}" placeholder="${escapeHTML(f[2])}"></textarea>`}else{control=`<input id="${id}" type="${f[1]}" placeholder="${escapeHTML(f[2])}" ${f[1]==='text'&&i===0?'required':''} ${f[1]==='date'?'value="2026-10-10"':''}>`}return `<div class="field ${f[1]==='textarea'?'full':''}"><label for="${id}">${f[0]}</label>${control}</div>`}).join('')}</form>`;
 $('#modalSave').textContent=({profile:'Tutup',backup:'Buat backup',pulihkan:'Pulihkan'})[type]||'Simpan';
 $('#modalBackdrop').hidden=false;
}
function closeModal(){$('#modalBackdrop').hidden=true}

function modalKey(){ return (typeof PAGE!=='undefined'&&PAGE.modalKey)?PAGE.modalKey():state.page; }

/* ---------- sesi (login/logout) ---------- */
function logout(){ try{sessionStorage.removeItem('gp_role')}catch(e){} go('index.html'); }
function applyTheme(t){
  state.theme=t;document.documentElement.dataset.theme=t;try{localStorage.setItem('gp_theme',t)}catch(e){}
  const b=$('#themeToggle');if(b){b.textContent=t==='light'?'☾':'☀';b.title=t==='light'?'Aktifkan dark mode':'Aktifkan light mode';iconize(b)}
}

/* ---------- navbar.html dipanggil dari setiap halaman ---------- */
async function loadNavbar(){
  const slot=$('#navbar');
  try{const r=await fetch('navbar.html');if(!r.ok)throw new Error(r.status);slot.innerHTML=await r.text();return true}
  catch(e){slot.innerHTML='<div class="load-error">Navbar tidak bisa dimuat. Buka proyek lewat server lokal (mis. ekstensi <code>Live Server</code> di VS Code atau <code>python -m http.server</code>), bukan dengan klik dua kali file HTML.</div>';return false}
}
function buildNav(){
  $('#mainNav').innerHTML=MENU[state.role].map(([l,ids])=>(l?`<div class="nav-section-label">${l}</div>`:'')+ids.map(id=>`<a class="nav-item${id===state.page?' active':''}" href="${id}.html"><span class="nav-icon">${NAVI[id]}</span> ${pg(id).crumb}</a>`).join('')).join('');
  const p=me();$('#sidebarName').textContent=p.name;$('#sidebarRole').textContent=roleNames[state.role];
  const av=$('#sidebarAvatar');av.textContent=p.initials;av.className='avatar '+(state.role==='tutor'?'avatar-green':state.role==='student'?'avatar-orange':'avatar-purple');
  $('#breadcrumbCurrent').textContent=pg().crumb;
  $('#scrim').addEventListener('click',()=>$('#sidebar').classList.remove('open'));
  $('#menuToggle').addEventListener('click',()=>$('#sidebar').classList.toggle('open'));
  $('#themeToggle').addEventListener('click',()=>applyTheme(state.theme==='light'?'dark':'light'));
}

/* ---------- isi halaman ---------- */
function renderPage(){
  const m=pg(),p=me();
  $('#pageTitle').innerHTML=state.page==='dashboard'?p.greeting:m.title;
  const a=$('#primaryAction');a.innerHTML=m.action;a.style.display=m.action?'inline-flex':'none';
  refreshPage();
}
function refreshPage(){
  $('#pageContent').innerHTML=PAGE.render();
  if(PAGE.after)PAGE.after();
  labelTables();iconize(document.body);
}

/* ---------- aksi tombol (delegasi klik) ---------- */
const ACT={
  profile:()=>openModal('profile'),edit:n=>openModal('generic',n),viewProgram:n=>openModal('program',n),
  logout,attend:n=>openModal('absensi',n),grade:n=>openModal('catatan',n),reqchange:()=>openModal('jadwalReq'),
  del:()=>toast('Dihapus (demo).'),toggle:()=>toast('Status diubah (demo).'),join:()=>toast('Membuka sesi… (demo)'),
  remind:()=>toast('Pengingat aktif.'),enroll:()=>toast('Pendaftaran terkirim (demo).')
};
function wireGlobal(){
  document.addEventListener('click',e=>{
    const nav=e.target.closest('[data-page]');if(nav){go(nav.dataset.page+'.html');return}
    const el=e.target.closest('[data-action]');if(el)(ACT[el.dataset.action]||(()=>{}))(el.dataset.name||'');
  });
  $('#primaryAction').addEventListener('click',()=>openModal(modalKey()));
  $('#modalClose').addEventListener('click',closeModal);$('#modalCancel').addEventListener('click',closeModal);
  $('#modalBackdrop').addEventListener('click',e=>{if(e.target===$('#modalBackdrop'))closeModal()});
  $('#modalSave').addEventListener('click',()=>{if(state.modalType==='profile'){closeModal();return}const f=$('#demoForm');if(f&&!f.reportValidity())return;const t=state.modalType,done=PAGE.onSave&&PAGE.onSave(t);closeModal();if(!done)toast('Tersimpan (demo).')});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeModal();const s=$('#sidebar');if(s)s.classList.remove('open')}});
}

/* ---------- alur awal setiap halaman ---------- */
document.addEventListener('DOMContentLoaded',async()=>{
  let role=null;try{role=sessionStorage.getItem('gp_role')}catch(e){}
  if(!role||!roleProfiles[role]){go('index.html');return}
  state.role=role;
  if(!allowed(state.page)){go('dashboard.html');return}
  ensureOverlay();
  if(await loadNavbar())buildNav();
  try{state.theme=localStorage.getItem('gp_theme')||'light'}catch(e){}
  wireGlobal();renderPage();applyTheme(state.theme);
});
